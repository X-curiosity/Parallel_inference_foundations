#include <algorithm>


typedef unsigned long long data_t;


int getMax(data_t *data,int n){

    int mx = data[0];
    for (int i = 1; i < n; i++)
        if (data[i] > mx)
            mx = data[i];
    return mx;

}

void countSort(data_t *data, int n, int exp)
{
    // output array
    int output[n];
    int i, count[10] = { 0 };

    // Store count of occurrences in count[]
    for (i = 0; i < n; i++)
        count[(data[i] / exp) % 10]++;

    // Change count[i] so that count[i] now contains actual
    // position of this digit in output[]
    for (i = 1; i < 10; i++)
        count[i] += count[i - 1];

    // Build the output array
    for (i = n - 1; i >= 0; i--) {
        output[count[(data[i] / exp) % 10] - 1] = data[i];
        count[(data[i] / exp) % 10]--;
    }

    // Copy the output array to arr[], so that arr[] now
    // contains sorted numbers according to current digit
    for (i = 0; i < n; i++)
        data[i] = output[i];
}


void psort(int n, data_t *data) {
    // FIXME: Implement a more efficient parallel sorting algorithm for the GPU.

    // Find the maximum number to know number of digits
    int m = getMax(data, n);

    // Do counting sort for every digit. Note that instead
    // of passing digit number, exp is passed. exp is 10^i
    // where i is current digit number
    for (int exp = 1; m / exp > 0; exp *= 10)
        countSort(data, n, exp);
    


}
